#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <Windows.h>
#include "CheckSumComputer.h"
#include "Constants.h"
#include "DataRecord.h"
#include "States.h"
#include "TypesOfRecord.h"

using namespace std;

typedef void(*RecordWriter)(byte*, byte);

void CustomizeConsole();
void InitializeWorkspace(byte*&, States&, TypesOfRecord&, RecordWriter&);
void ReactOnState(States, byte*&, byte&, TypesOfRecord, RecordWriter);
void ChooseNewState(States&, byte, TypesOfRecord, RecordWriter&);
bool IsStandardLength(byte);
byte ReadByte();
void ReadRecord(byte*&, byte);
TypesOfRecord CheckRecordType(byte);
void TryWriteRecordData(byte*, byte, RecordWriter);
bool BaseRecordIsCorrect(byte*, byte);
void TryWriteBaseRecordData(byte*, byte);
bool SignalRecordIsCorrect(byte);
void TryWriteSignalRecordData(byte*, byte);
void CleanWorkspace(byte*&);
void InformAboutFinish();