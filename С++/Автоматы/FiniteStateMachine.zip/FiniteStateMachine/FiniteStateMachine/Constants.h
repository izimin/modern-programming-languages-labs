#pragma once

const unsigned char SyncByte = 0xAA;
const unsigned char DataRecordID = 0x87;
const unsigned char SignalRecordID = 0x98;
const unsigned char StandardDataRecordLength = 45;
const unsigned char StandardSignalRecordLength = 2;
const int BeginningOfChecksumBlock = 43;
const int SignalIndex = 1;