#pragma once

enum class States
{
	LookingForSYNCBytes,
	ReadingSYNCByte,
	ReadingLENByte,
	ReadingRecord,
	CheckingRecordType,
	WritingRecordData,
	End
};