#pragma once

struct DataRecord 
{
	int Ax;
	int Ay;
	int Az;
	int Wx;
	int Wy;
	int Wz;
	short Tax;
	short Tay;
	short Taz;
	short Twx;
	short Twy;
	short Twz;
	short S;
	short Timestamp;
	unsigned char Status;
	unsigned char Number;
};