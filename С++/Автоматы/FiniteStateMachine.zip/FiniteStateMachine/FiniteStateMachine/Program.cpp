#include "Main.h"

ifstream inputFile; 
ofstream outputDataFile; 
ofstream outputSignalsFile;

int main()
{
	CustomizeConsole();
	States state;
	byte readenByte;
	byte* buffer;
	TypesOfRecord typeOfRecord;
	RecordWriter recordWriter;
	InitializeWorkspace(buffer, state, typeOfRecord, recordWriter);
	while (state != States::End)
	{
		ReactOnState(state, buffer, readenByte, typeOfRecord, recordWriter);
		ChooseNewState(state, readenByte, typeOfRecord, recordWriter);
	}
	CleanWorkspace(buffer);
	InformAboutFinish();
}

void CustomizeConsole()
{
	SetConsoleOutputCP(1251);
	SetConsoleCP(1251);
}

void InitializeWorkspace(byte*& buffer, States& state, TypesOfRecord& typeOfRecord, RecordWriter& recordWriter) 
{
	recordWriter = nullptr;
	typeOfRecord = TypesOfRecord::Data;
	state = States::LookingForSYNCBytes;
	buffer = new byte[45];
	string fileName;
	do {
		cout << "��� �������� �����: ";
		cin >> fileName;
		inputFile = ifstream(fileName, ios::binary);
		if (!inputFile)
			cout << "������������� ���� �� ����������.\n";
	} while (!inputFile);
	cout << "��� ��������� �����: ";
	cin >> fileName;
	outputDataFile = ofstream(fileName, ios::trunc);
	outputDataFile << "Ax|Ay|Az|Wx|Wy|Wz|Tax|Tay|Taz|Twx|Twy|Tws|S|Timestamp|Status|Number\n";
	outputSignalsFile = ofstream("signals.txt");
}

void ReactOnState(States state, byte*& buffer, byte& readenByte, TypesOfRecord typeOfRecord, RecordWriter recordWriter)
{
	switch (state)
	{
		case States::LookingForSYNCBytes:
		{
			readenByte = ReadByte();
			break;
		}
		case States::ReadingSYNCByte:
		{
			readenByte = ReadByte();
			break;
		}
		case States::ReadingLENByte:
		{
			readenByte = ReadByte();
			break;
		}
		case States::ReadingRecord:
		{
			ReadRecord(buffer, readenByte);
			break;
		}
		case States::CheckingRecordType:
		{
			CheckRecordType(buffer[0]);
			break;
		}
		case States::WritingRecordData:
		{
			TryWriteRecordData(buffer, readenByte, recordWriter);
			break;
		}
	}
}

void ChooseNewState(States & state, byte readenByte, TypesOfRecord typeOfRecord, RecordWriter& recordWriter)
{
	switch (state)
	{
		case States::LookingForSYNCBytes:
		{
			state = inputFile.eof() ? 
						States::End : 
						readenByte == SyncByte ? 
							States::ReadingSYNCByte :
							States::LookingForSYNCBytes;
			break;
		}
		case States::ReadingSYNCByte:
		{
			state = readenByte == SyncByte ? 
						States::ReadingLENByte :
						States::LookingForSYNCBytes;
			break;
		}
		case States::ReadingLENByte:
		{
			state = IsStandardLength(readenByte) ?
						States::ReadingRecord : 
						States::LookingForSYNCBytes;
			break;
		}
		case States::ReadingRecord:
		{
			state = States::CheckingRecordType;
			break;
		}
		case States::CheckingRecordType:
		{
			state = States::WritingRecordData;
			switch (typeOfRecord)
			{
				case TypesOfRecord::Data:
				{
					recordWriter = &TryWriteBaseRecordData;
					break;
				}
				case TypesOfRecord::Signal:
				{
					recordWriter = &TryWriteSignalRecordData;
					break;
				}
				default:
				{
					recordWriter = nullptr;
					state = States::LookingForSYNCBytes;
					break;
				}
			}
			break;
		}
		case States::WritingRecordData:
		{
			state = States::LookingForSYNCBytes;
			break;
		}
	}
}

bool IsStandardLength(byte recordLength)
{
	return recordLength == StandardDataRecordLength || recordLength == StandardSignalRecordLength;
}

byte ReadByte()
{
	byte result = 0;
	inputFile.read(reinterpret_cast<char*>(&result), sizeof(byte));
	return result;
}

void ReadRecord(byte*& buffer, byte recordLength)
{
	inputFile.read(reinterpret_cast<char*>(buffer), sizeof(byte)*recordLength);
}

TypesOfRecord CheckRecordType(byte typeByte)
{
	TypesOfRecord typeOfRecord;
	switch (typeByte)
	{
		case DataRecordID:
		{
			typeOfRecord = TypesOfRecord::Data;
			break;
		}
		case SignalRecordID:
		{
			typeOfRecord = TypesOfRecord::Signal;
			break;
		}
		default:
		{
			typeOfRecord = TypesOfRecord(-1);
			break;
		}
	}
	return typeOfRecord;
}

void TryWriteRecordData(byte* buffer, byte recordLength, RecordWriter recordWriter)
{
	recordWriter(buffer, recordLength);
}

void TryWriteBaseRecordData(byte* buffer, byte recordLength)
{
	if (!BaseRecordIsCorrect(buffer, recordLength))
		return;
	DataRecord record = *reinterpret_cast<DataRecord*>(buffer+1);
	outputDataFile << record.Ax << '|' << record.Ay << '|' << record.Az << '|' << record.Wx << '|' << record.Wy << '|' << record.Wz << '|';
	outputDataFile << record.Tax << '|' << record.Tay << '|' << record.Taz << '|' << record.Twx << '|' << record.Twy << '|' << record.Twz << '|' << record.S << '|';
	outputDataFile << record.Timestamp - '\0' << '|' << record.Status - '\0' << '|' << record.Number - '\0';
	outputDataFile << '\n';
}

bool BaseRecordIsCorrect(byte* buffer, byte recordLength)
{
	return recordLength == StandardDataRecordLength &&
		unsigned short(*reinterpret_cast<short *>(&buffer[BeginningOfChecksumBlock]))
		== CheckSumComputer::CRC16(buffer, recordLength - 2);
}

void TryWriteSignalRecordData(byte* buffer, byte recordLength)
{
	if (SignalRecordIsCorrect(recordLength))
		outputSignalsFile << buffer[SignalIndex] - '\0' << '\n';
}

bool SignalRecordIsCorrect(byte recordLength)
{
	return recordLength == StandardSignalRecordLength;
}

void CleanWorkspace(byte*& buffer)
{
	inputFile.close();
	outputDataFile.close();
	outputSignalsFile.close();
	delete[] buffer;
	buffer = nullptr;
}

void InformAboutFinish() 	
{
	"������ ��������� ���������.\n";
}