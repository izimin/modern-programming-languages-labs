#pragma once

enum class TypesOfRecord
{
	Data,
	Signal
};